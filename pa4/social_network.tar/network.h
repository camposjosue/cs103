#ifndef NETWORK_H
#define NETWORK_H

class Network {
 public:

 private:
};


#endif
