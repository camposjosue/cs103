#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
  int red;
  int green;
  int blue;
  cout << "R Component";
  cin >> red;
  cout << "G Component";
  cin >> green;
  cout << "B Component";
  cin >> blue;

  white = max((red/255),(green/255),(blue/255));

  cyan =((white-(red/255))/white);
  magenta = ((white-(green/255))/white);
  yellow = ((white-(blue/255))/white);
  black = 1-white;

  cout << "C=" << cyan << " M=" << magenta << " Y=" << yellow << " K=" << black << endl;


// Enter your code here




  return 0;
}
